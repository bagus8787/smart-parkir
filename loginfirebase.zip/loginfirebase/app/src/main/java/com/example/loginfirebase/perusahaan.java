package com.example.loginfirebase;

import com.google.firebase.database.Exclude;

import java.util.HashMap;
import java.util.Map;

public class perusahaan {
    public String nama;
    public String email;
    public String no_hp;

    public perusahaan(){

    }

    public perusahaan(String nama, String email, String no_hp){
        this.nama = nama ;
        this.email = email;
        this.no_hp = no_hp;
    }

    @Exclude
    public Map<String, Object> toMap(){
        HashMap<String, Object> result = new HashMap<>();
        result.put("nama", nama);
        result.put("email", email);
        result.put("no_hp", no_hp);
        return result;
    }
}

package com.example.loginfirebase;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.example.loginfirebase.R;

public class PerusahaanViewHolder extends RecyclerView.ViewHolder {

    public  TextView tvnama;
    public  TextView tvemail;
    public  TextView tvno_hp;
    public  TextView btnOpen;



    public PerusahaanViewHolder(View itemView) {
        super(itemView);
        tvnama = itemView.findViewById(R.id.tv_nama);
        tvemail = itemView.findViewById(R.id.tv_email);
        tvno_hp = itemView.findViewById(R.id.tv_no_tlp);
        btnOpen = itemView.findViewById(R.id.btn_open);
    }

    public void bindToperusahaan(perusahaan perusahaan, View.OnClickListener onClickListener){
        tvnama.setText(perusahaan.nama);
        tvemail.setText(perusahaan.email);
        tvno_hp.setText(perusahaan.no_hp);
        btnOpen.setOnClickListener(onClickListener);
    }

}

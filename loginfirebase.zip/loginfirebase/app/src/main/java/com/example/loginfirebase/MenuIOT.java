package com.example.loginfirebase;

import android.graphics.drawable.TransitionDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.SwitchCompat;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import android.os.Handler;
import android.widget.Toast;

public class MenuIOT extends AppCompatActivity {

    Boolean turnOn=false;

    private FirebaseAuth auth;

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference();

    final DatabaseReference ledstatus1 = myRef.child("led1").child("status");
    final DatabaseReference ledstatus2 = myRef.child("led2").child("status");

    Button b1, b2;
    TextView led1, led2, tv_count, switchStatus;
    ImageView imagee;
    Switch mySwitch;
    Button btn;

    int angka = 0;
    Handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_iot);

        imagee = (ImageView) findViewById(R.id.image);

        led1 = (TextView) findViewById(R.id.led1);
        led2 = (TextView) findViewById(R.id.led2);

        btn = (Button) findViewById(R.id.button);

        mySwitch = (Switch) findViewById(R.id.mySwitch);

        ledstatus1.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                String value = dataSnapshot.getValue(String.class);
                Log.d("file", "Value is: " + value);
                led1.setText(value);

            }

            @Override
            public void onCancelled(DatabaseError error) {

                Log.w("File", "Failed to read value.", error.toException());

            }
        });

        ledstatus2.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                String value = dataSnapshot.getValue(String.class);
                Log.d("file", "Value is: " + value);
                led2.setText(value);

            }

            @Override
            public void onCancelled(DatabaseError error) {

                Log.w("File", "Failed to read value.", error.toException());

            }
        });


        //set swicth to ON
        mySwitch.setChecked(true);

        mySwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (!turnOn){
                    ledstatus1.setValue("ON");
                    imagee.setImageResource(R.drawable.trans_on);
                    ((TransitionDrawable)imagee.getDrawable()).startTransition(3000);
                    Toast.makeText(getApplicationContext(),"Lampu Hidup",Toast.LENGTH_SHORT).show();
                    turnOn=true;

                } else {
                    ledstatus1.setValue("OFF");
                    imagee.setImageResource(R.drawable.trans_off);
                    ((TransitionDrawable)imagee.getDrawable()).startTransition(3000);
                    Toast.makeText(getApplicationContext(),"Lampu Mati",Toast.LENGTH_SHORT).show();
                    turnOn=false;
                }
            }
        });

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!turnOn){
                    imagee.setImageResource(R.drawable.trans_on);
                    ((TransitionDrawable)imagee.getDrawable()).startTransition(4000);
                    turnOn = true;
                } else {
                    imagee.setImageResource(R.drawable.trans_off);
                    ((TransitionDrawable)imagee.getDrawable()).startTransition(4000);
                    turnOn = false;

                }
            }
        });



        if (mySwitch.isChecked()){
            ledstatus1.setValue("ON");
        } else {
            ledstatus1.setValue("OFF");
        }


    }




}
